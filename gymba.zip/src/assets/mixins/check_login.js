import axios from '../../api'

export default {
  methods: {
    check_loged() {
      axios.post('LoginLogic/check_login', {
        sid: window.localStorage.getItem('session-id')
      })
      .then()
      .catch(e => {this.response = e})
    }
  }
}


  
