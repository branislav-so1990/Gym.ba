<script>
import { Line } from 'vue-chartjs'

export default {
  extends: Line,
  props: {
    chartdata: {
      type: Object,
      default: null,
    }
  },
  data() {
    return {
      options: {
        responsive: true,
        maintaintAspectRatio: false,
        height: 200,
        legend: {
          labels: {
            fontColor: '#fff',
            fontSize: 20
          }
        },
        scales: {
          yAxes: [{
            ticks: {
              fontColor: '#ccc',
              fontSize: 14,
              padding: 15
            }
          }],
          xAxes: [{
            ticks: {
              fontColor: '#ccc',
              fontSize: 14
            }
          }]
        }
      }
    }
  },
  mounted() {
    this.renderChart(this.chartdata, this.options)
  }
}
</script>

<style scoped>

</style>