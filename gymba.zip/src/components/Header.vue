<template>
  <header class="headline">
    <img src="../assets/images/app/desktop_logo.png" class="logo">
    <div class="title">
      <h1> Gym.ba </h1>
      <span> Your most productive workout. </span>
    </div>
  </header>
</template>

<script>
export default {

}
</script>

<style>
  .headline {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 auto 25px;
  }
  .logo {
    display: inline-block;
    height: 100px;
  }
  .title {text-align: left}
  .headline h1 {
    font-size: 4rem;
    line-height: 65px;
  }
  .headline span {
    /* border: 1px dashed white; */
    font-size: 1.3rem;
    row-gap: 0px;
    letter-spacing: -0.5px;
    word-spacing: -5px;
    color: var(--main-red-color);
    font-weight: 700;
    padding-left: 5px;
  }
</style>