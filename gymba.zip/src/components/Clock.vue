<template>
  <div class="clock">
    {{hours | two_digits}}:{{minutes | two_digits}}
  </div>
</template>

<script>
export default {
  data() {
    return {
      hours: new Date().getHours(),
      minutes: new Date().getMinutes()
    }
  },
  created() {
    window.setInterval(() => {
      this.hours = new Date().getHours()
      this.minutes = new Date().getMinutes()
    }, 1000)
  }
}
</script>

<style scoped>
  .clock {
    position: absolute;
    top: 4.2%;
    left: 15%;
    font-weight: 700;
    color: #ccc;
  }
</style>