<template>
<div class='wrapper'>
  <!-- <div class="block">
    <p class="digit">{{days | two_digits}}</p>
    <p class="text">Days </p>
  </div>
  <div class="block">
    <p class="digit">{{hours | two_digits}}</p>
    <p class="text">Hours </p>
  </div> -->
  <div class="block">
    <p class="digit"> {{hours | two_digits}}:{{minutes | two_digits}}:{{seconds | two_digits}} </p>
  </div>
</div>
</template>

<script>

export default {

  props : {
    date : {
      type: Date
    }
  },
  data() {
    return {
      // current time value in seconds
      now: Math.trunc((new Date()).getTime() / 1000),
      intID: 0 
    }
  },
  created() {
    // setInterval for every second
    this.intID = window.setInterval(() => {
      this.now = Math.trunc((new Date()).getTime() / 1000)
    }, 1000)

    this.$nextTick(function(){
      this.$emit('event-child', this.intID)
    })
  },
  computed: {
    // convert date string to number
    date_converted() {
      return Math.trunc(Date.parse(this.date) / 1000)
    },
    seconds() {
      return Math.abs((this.date_converted - this.now) % 60)
    },
    minutes() {
      return Math.abs(Math.trunc((this.date_converted - this.now) / 60) % 60)
    },
    hours() {
      return Math.abs(Math.trunc((this.date_converted - this.now) / 60 / 60) % 24)
    },
    days() {
      return Math.abs(Math.trunc((this.date_converted - this.now) / 60 / 60 / 24))
    }
  },
}
</script>

<style scoped>
  
</style>