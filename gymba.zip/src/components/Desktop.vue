<template>
  <aside class="desktop-screen">
    <div class="blured-backg"></div>

    <div class="wrapper">
      <div class="headline" v-bind:class='{ disabled : user_status }'>
        <img src="../assets/images/app/desktop_logo.png" class="logo" >
        <div class="title" >
          <h1> Gym.ba </h1>
          <span > Your most productive workout. </span>
        </div>
      </div><!-- end of title -->

      <!-- Login window -->
      <div class="login" v-bind:class='{ disabled : user_status }'>
        <p> Get stronger, faster with a fitness plan that fits you! </p>
        <p> Track your progress here, now! </p>

        <label> <i class="icon fas fa-envelope"></i> E-mail </label>
        <input type="text" v-model='email' placeholder="enter e-mail">
        
        <label> <i class="icon fas fa-unlock-alt"></i> Password </label>
        <input type="password" v-model='password' placeholder="enter password">

        <button @click='login'> Login now </button>
        <span class="response"> {{response}} </span>
      </div><!-- end of login window -->

      <!-- User profile page -->
      <UserProfile v-bind:picture="profile_pic" v-bind:class='{ disabled : !user_status }'/>
      <!-- v-bind:class='{ disabled : !usere_status }' -->
    </div><!-- end of wrapper -->

  </aside>
</template>

<script>
import {bus} from '../main'
import store from '../store'
import axios from '../api'
import UserProfile from './Desktop_profile'
export default {
  components: {
    UserProfile
  },
  data() {
    return {
      // Login data
      email: '',
      password: '',
      response: '',
      profile_pic: store.state.avatar || ''
    }
  },
  computed: {
    user_status(){
      return store.state.user_loged
    }
  },
  methods: {
    login() {
      if (!this.email.trim() || !this.password.trim())
       return
      axios.post('LoginLogic/login', {
        email: this.email, 
        password: this.password
      })
      .then(response => {
         if ('sid' in response.data) {
          localStorage.setItem("session-id", response.data.sid)

          // send user data to store
          let user = response.data.User.stats
          store.commit('SET_USER_LOGED', {
            username: response.data.User.data.username,
            user_id: user.user_id,
            gender: user.gender,
            level: user.training_level,
            bmi: user.bmi,
            age: user.age,
            height: user.height,
            weight: user.weight,
            body_fat: user.body_fat
          })
          this.show_user_image()
          bus.$emit('user-loged')
          this.$router.push('profile')
        } else 
          this.response = response.data.Error
      })
      .catch(e => {this.response = e})
    },

    show_user_image() {
      axios.post('User/display_profile_picture', {user_id: store.state.user_obj.user_id})
      .then(response => {
        this.profile_pic = response.data.profile_picture.profile_picture
        store.commit('SET_AVATAR', {
          picture: response.data.profile_picture.profile_picture
        })
      })
      .catch(e => {this.response = e})
    }
  },
  created() {
    bus.$on('user-loged', () => {this.show_user_image()})
  }
}
</script>

<style scoped>
  
  .response {display: block}
  label {font-size: 1.3rem}
  .desktop-screen {
    height: 100vh;
    width: 680px;
    position: relative;
    top: 0;
    overflow-y: scroll;
    scrollbar-width: thin;
    scrollbar-color: var(--main-red-color) transparent;
  }
  .desktop-screen::-webkit-scrollbar-track {background-color: transparent}
  .blured-backg {
    background-color: #23282bd0;
    background-image: url('../assets/images/app/mobile-background.jpg');
    background-size: cover;
    opacity: 0.7;
    height: 100%;
    width: 100%;
    filter: blur(8px);
    -webkit-filter: blur(8px);
  }
  .wrapper {
    padding: 30px 50px;
    position: absolute;
    top: 0%;
    left: 0;
    right: 0;
    /* border: 1px dashed blue; */
  }
  .headline {
    display: flex;
    align-items: center;
    width: fit-content;
    margin: 0 auto 25px;
  }
  .logo {
    display: inline-block;
    height: 100px;
  }
  .title {text-align: left}
  .headline h1 {
    font-size: 4rem;
    line-height: 50px;
  }
  .headline span {
    font-size: 1.5rem;
    padding-left: 5px;
    color: var(--main-red-color);
    font-weight: 700;
  }

  .login {
    /* border: 1px dashed white; */
    height: fit-content;
    font-weight: 700;
    /* display: none; */
  }
  .login p {
    /* border: 1px dashed white; */
    font-size: 1.3rem;
  }
  .login p:last-of-type {
    text-transform: uppercase;
    font-size: 1.8rem;
    color: var(--main-red-color);
    margin: 5px 0 30px;
  }
  .disabled {display:none}
</style>