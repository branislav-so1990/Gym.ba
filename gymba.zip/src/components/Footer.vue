<template>
  <nav class="footer">
    <ul>
      <li> <router-link to="/choose_groups"> Exercises <i class="fas fa-heartbeat nav-icon"></i> </router-link> </li>
      <li> <router-link to="/workout"> Workout <i class="fas fa-dumbbell nav-icon"></i> </router-link> </li>
      <li> <router-link to="/nutrition"> Nutrition <i class="fas fa-blender nav-icon"></i> </router-link> </li>
      <li> <router-link to="/profile"> Me <i class="fas fa-user-cog nav-icon"></i> </router-link> </li>
    </ul>
  </nav>
</template>

<script>
export default {

}
</script>

<style>
  .footer {
    background-color: #3a3f43;
    padding: 35px 0 0;
    position: absolute;
    bottom: 0;
    width: 100%;
  }
  .nav-icon {
    position: absolute;
    top: -70%;
    left: 50%;
    transform: translate(-50%,-70%);
    font-size: 1.6rem;
  }
  .footer ul {
    display: flex;
    justify-content: space-around;
  }
  .footer li {
    list-style: none;
    position: relative;
    cursor: pointer;
    transition: 250ms ease-in-out;
    text-transform: uppercase;
    font-weight: 700;
    font-size: 0.7rem;
    width: 25%;
    position: relative;
  }
 .footer li:hover {opacity: 0.5}
  
</style>