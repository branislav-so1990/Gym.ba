<template>
  <section class="user-profile">
    <p class="title"> Welcome back! <span></span>  </p>
    <p class='sign-out' @click='sign_out'> Sign out <i class="fas fa-sign-out-alt"></i> </p>

    <article class="user-options">
      <label>
         <div class="user-avatar">
          <img v-if="picture == null" src="../assets/images/app/no-user-avatar.png">
          <img v-else :src="picture">
          <input type="file" @change="on_file_change" style='display:none'>
        </div>
      </label>
      
      <div class="user-data">
        <div class="data-wrapper">
          <label> Username </label>
          <input type="text" :value="user.username" ref="edit_username" placeholder="Username">
          <div class="wrapper">
            <div>
              <label> Weight - kg </label>
              <input type="number" :value="user.weight" ref="edit_weight" placeholder="Weight">
            </div>
            <div>
              <label> Height - cm </label>
              <input type="number" :value="user.height" ref="edit_height" placeholder="Height">
            </div>
          </div><!-- end of wrapper -->
        </div>
        <button @click='edit_user'> Apply changes </button>
      </div><!-- end of user-data -->

      <div class="users-stats">
        <label> {{user.username}} stats: </label>
        <p> Age: {{ user.age }} </p>
        <p> Gender: {{ user.gender }} </p>
        <p> Experience: <br> {{ level }} </p>
        <p> BMI: {{ user.bmi }} </p>

        <div>
          <button @click="show_totalweight_chart" class='chart-btns'> All workouts </button>
          <button @click="show_benchpress_chart" class='chart-btns'> Bench press </button>
        </div>
      </div>

      <div class="user-charts">
        <Chart class='chart' v-if="loaded" :chartdata='chartdata' />
      </div>
    </article>

    <p class="response">{{ response }}</p>
  </section>
</template>

<script>
import {bus} from '../main'
import axios from '../api'
import store from '../store'
import Chart from '../components/Chart'

export default {
  components: {Chart},
  props: {picture: String},
  data() {
    return {
      avatar: null,
      response: '',
      profile_pic: null || "../assets/images/app/no-user-avatar.png",

      // Chart data
      loaded: false,
      chartdata: null
    }
  },
  computed: {
    user() {
      let data = {
        user_id: store.state.user_obj.user_id,
        username: store.state.user_obj.username,
        gender: store.state.user_obj.gender,
        // level: store.state.user_obj.level,
        age: store.state.user_obj.age,
        bmi: store.state.user_obj.bmi,
        weight: store.state.user_obj.weight,
        height: store.state.user_obj.height,
        body_fat: store.state.user_obj.body_fat,
      }
      return data
    },
    level() {
      let level = store.state.user_obj.level
      switch(level) {
        case 1:
          level = 'Beginer'
          break 
        case 2:
          level = 'Intermediate'
          break 
        case 3:
          level = 'Advanced'
          break 
      }
      return level
    }
  },
  methods: {
    on_file_change(e) {
      this.avatar = e.target.files[0]
      const formData = new FormData()
      formData.append('file',this.avatar,this.avatar.name)
      formData.append('user_id', this.user.user_id)
      axios.post('User/profile_picture', formData)
      .then(response => {
        this.response = response.data.status
        bus.$emit('user-loged')
      })
      .catch(e => {this.response = e})
    },

    sign_out() {
      axios.post('LoginLogic/logout', {
        sid: window.localStorage.getItem('session-id')
      })
      .then(() => {
        store.commit('SET_USER_LOGEDOUT')
        store.commit('REMOVE_AVATAR')
        window.localStorage.removeItem('session-id')
        window.localStorage.removeItem('vuex')
        this.$router.push('/')
      })
			.catch((e) => {this.response = e})
    },

    edit_user() {
      // Odvojeno saljem id i username
      axios.post('User/user_update', {
        user_id: this.user.user_id,
        username: this.$refs.edit_username.value
      })
      .then(response => {store.commit('UPDATE_USERNAME', {username: response.data.data.username})})
      .catch(e => {this.response = e})

      // Odvojeno saljem id height i weight
      axios.post('User/body_stats_update', {
        user_id: this.user.user_id,
        weight: this.$refs.edit_weight.value,
        height: this.$refs.edit_height.value
      })
      .then(response => {
        this.response = response.data.stats
        store.commit('UPDATE_BODY_STATS', {
          weight: response.data.weight,
          height: response.data.height
        })
      })
      .catch(e => {this.response = e })
      bus.$emit('user-edited')
    },

    show_user_image() {
      axios.post('User/display_profile_picture', {user_id: store.state.user_obj.user_id})
      .then(response => {
        this.profile_pic = response.data.profile_picture.profile_picture
        store.commit('SET_AVATAR', {
          picture: response.data.profile_picture.profile_picture
        })
      })
      .catch(e => {this.response = e})
    },

    show_totalweight_chart() {
      this.loaded = false
      this.chartdata = null
      axios.post('Workout/return_totalweight_chart_data', {user_id: store.state.user_obj.user_id})
      .then(response => {
        this.chartdata = response.data.chartdata
        this.loaded = true
      })
      .catch(e => {console.log(e)})
    },

    show_benchpress_chart() {
      this.loaded = false
      this.chartdata = null
      axios.post('Workout/return_bench_press_chart_data', {user_id: store.state.user_obj.user_id})
      .then(response => {
        this.chartdata = response.data.chartdata
        this.loaded = true
      })
      .catch(e => {console.log(e)})
    }
  },
  mounted() { 
    this.show_totalweight_chart()
    bus.$on('user-loged', () => {this.show_totalweight_chart()})
  },
  created() {
    bus.$on('workout-completed', () => {this.show_totalweight_chart()})
  }
}
</script> 

<style scoped>
  .user-profile {
    /* border: 1px dashed white; */
    height: 500px;
    max-height: 550px;
    position: relative;
  }
  .title {
    font-size: 1.5rem;
    text-align: center;
    color: #ccc;
    margin-bottom: 25px;
    text-transform: none;
  }
  .title span {
    display: block;
    text-transform: uppercase;
  }
  .sign-out {
    cursor: pointer;
    font-size: 1.2rem;
    font-weight: 700;
    transition: 250ms all ease-in-out;
    position: absolute;
    top: 0;
    right: 0;
    padding: 5px 10px;
    border-radius: 7px;
  }
  .sign-out:hover {
    color: var(--main-red-color);
  }

  .user-options {
    display: grid;
    /* grid-template-columns: 1fr 2fr; */
    /* grid-template-rows: 1fr 1fr; */
    grid-row-gap: 20px;
    grid-template-areas: 
      'avatar data'
      'stats  charts'
  }
  .user-avatar {
    border: 2px solid var(--main-red-color);
    font-size: 3rem;
    color: #777;
    height: 150px;
    width: 150px;
    /* border-radius: 31% 19% 44% 25% / 35% 22% 71% 38%; */
    border-radius: 20px;
    background-color: var(--main-bg-color);
    box-shadow:  5px 5px 15px 5px rgba(0,0,0,0.2);
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0.9;
    grid-area: avatar;
    cursor: pointer;
    transition: 250ms all ease-in-out;
    overflow: hidden;
  }
  .user-avatar img {
    height: 100%;
    width: 100%;
    object-fit: cover;
    opacity: 0.5;
    transition: 250ms all ease-in-out;
  }
  .user-avatar:hover img {
    opacity: 0.7;
    background-color: #2d3336;
  }
  label {
    margin: 3px;
    width: 100%;
    font-weight: 700;
    color: #ccc;
    height: fit-content;
  }
  .user-data {
    /* border: 1px dashed white; */
    display: flex;
    align-items: center;
    grid-area: data;
  }
  .user-data button {
    display: block;
    border-radius: 20px;
    height: 100%;
    padding: 50px 10px;
    line-height: 20px;
    margin: auto;
  }
  .data-wrapper {
    /* border: 1px dashed green; */
    width: 100%;
  }
  .wrapper {
    /* border: 1px dashed red; */
    display: flex;
    justify-content: space-evenly;
  }
  .wrapper > div {
    width: 45%;
  }
  .users-stats {
    /* border: 1px dashed white; */
    grid-area: stats;
    text-align: left;
  }
  .user-charts {
    /* border: 1px dashed red; */
    grid-area: charts;
  }
  .chart {
    /* border: 1px solid green; */
  }
  .chart-btns {
    padding: 10px;
    text-transform: none;
    display: block;
  }
</style>