<template>
  <div class="not-found">
    <b>Error 404</b>
    <p>Sorry, page not found</p>

    <!-- Return icon -->
    <span class='return-icon' @click='$router.go(-1)'> <i class="icon fas fa-backward return"></i> </span>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>