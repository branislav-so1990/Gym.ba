<template>
  <section class="login-page">

    <Header/>

    <div class="login">
      <label> <i class="icon fas fa-envelope"></i> E-mail </label>
      <input type="text" v-model='email' placeholder="enter e-mail">
      
      <label> <i class="icon fas fa-unlock-alt"></i> Password </label>
      <input type="password" v-model='password' placeholder="enter password">

      <button @click='login'> Login </button>
      
      <p class="response"> {{ response }} </p>
      
      <p class="no-acc"> No account? <router-link to="/get_started"> Get started here! </router-link> </p>
    </div>

    <!-- Return icon -->
    <router-link to="/" class='return-icon'> <i class="icon fas fa-backward return"></i> </router-link>

  </section>
</template>

<script>
import {bus} from '../../main'
import axios from '../../api'
import store from '../../store'
import Header from '@/components/Header'
export default {
  components: {
    Header
  },
  data() {
    return {
      email: '',
      password: '',
      response: ''
    }
  },
  methods: {
    login() {
      if (!this.email.trim() || !this.password.trim())
        return
      axios.post('LoginLogic/login', {email: this.email,password: this.password})
      .then(response => {
        if ('sid' in response.data) {
          localStorage.setItem("session-id", response.data.sid)

          // send user data to store
          let user = response.data.User.stats
          store.commit('SET_USER_LOGED', {
            username: response.data.User.data.username,
            user_id: user.user_id,
            gender: user.gender,
            level: user.training_level,
            bmi: user.bmi,
            age: user.age,
            height: user.height,
            weight: user.weight,
            body_fat: user.body_fat
          })
          bus.$emit('user-loged')
          this.$router.push('profile')
        } else
          this.response = response.data.Error
      })
      .catch(e => { this.response = e })
    }
  }
}
</script>

<style scoped>
  Header { margin: 20px 0 50px 0 }
  .no-acc { margin-top: 15px }
  .no-acc a:hover {color: var(--main-red-color)}
  .no-acc a { 
    color: var(--main-font-color); 
    transition: 150ms all ease; 
    text-decoration: underline;
  }
  
  
  
</style>