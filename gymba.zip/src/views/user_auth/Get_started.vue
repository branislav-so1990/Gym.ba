<template>
  <section class="get-started">

    
    
    <!-- STEP ONE -->
    <article class="step-one" v-bind:class='{ hidden : !step1.active }'>
      <h2 class='title'> Let's get you started! </h2>
      <!-- Username -->
      <label> <i class="fas fa-user icon"></i> Userame </label>
      <input type="text" placeholder="Enter name" v-model='username'>
      <!-- E-mail -->
      <label> <i class="fas fa-envelope icon"></i> E-mail </label>
      <input type="email" placeholder="Enter e-mail" v-model='email' v-on:blur='valid_email'>
      <!-- Password -->
      <label> <i class="fas fa-unlock-alt icon"></i> Password </label>
      <input type="password" placeholder="Enter password" v-model='password'>
      <!-- Re-password -->
      <label> <i class="fas fa-unlock-alt icon"></i> Re-password </label>
      <input type="password" placeholder="Confirm password" v-model='re_password'>
    </article><!-- end of step one -->


    <!-- STEP TWO -->
    <article class="step-two" v-bind:class='{ hidden : !step2.active }'>
      <h2 class='title'> What are your body mesurements? </h2>
      <!-- Height -->
      <label> <i class="fas fa-user icon"></i> Height <span class="metric-unit"> cm </span> </label> 
      <input type="number" placeholder="Enter height" v-model='height'>
      <!-- Weight -->
      <label> <i class="fas fa-weight-hanging icon"></i> Weight <span class="metric-unit"> kg </span> </label>
      <input type="number" placeholder="Enter weight" v-model='weight'>
      <!-- Gender -->
      <label> <i class="fas fa-venus-mars icon"></i> Gender </label>
      <select v-model='gender'>
        <option value="male"> Male </option>
        <option value="female"> Female </option>
      </select>
      <!-- Age -->
      <label> <i class="fas fa-calendar icon"></i> Age </label>
      <input type="number" placeholder="Enter age" v-model='age'>
    </article><!-- end of step two -->


    <!-- STEP THREE -->
    <article class="step-three" v-bind:class='{ hidden : !step3.active }'>
      <h2 class='title'> How experienced are you with lifting weights? </h2>

      <label class="container">
        <aside class="info">
          <p> <i class="fas fa-chess-pawn icon"></i> Beginer </p>
          <span> You heaven't tried weighted excercises or you just started lifting weights. </span>
        </aside>
        <input type="radio" name="experience" value='1' v-model='experience'> <span class="checkmark"></span>
      </label><!-- end of beginer -->

      <label class="container">
        <aside class="info">
          <p> <i class="fas fa-chess-knight icon"></i> Intermediate </p>
          <span> You've tried and practiced common weighted excercises. </span>
        </aside>
        <input type="radio" name="experience" value='2' v-model='experience'> <span class="checkmark"></span>
      </label><!-- end of intermediate -->

      <label class="container">
        <aside class="info">
          <p> <i class="fas fa-chess-king icon"></i> Advanced </p>
          <span> You've practiced strength-training for years. Compound barbell excercises are your jam! </span>
        </aside>
        <input type="radio" name="experience" value='3' v-model='experience'> <span class="checkmark"></span>
      </label><!-- end of advanced -->

      <button @click='lets_begin'> Let's begin </button>
    </article><!-- end of step three -->
    
    <p class="response"> {{ response }} </p>
    <!-- error: {{error}} -->

    <!-- STEP NAVIGATION -->
    <nav class="progres-bar">
      <ul>
        <li @click='step_one' v-bind:class='{ is_active:step1.active, is_completed:step1.completed }'> Step 1 </li>
        <li @click='step_two' v-bind:class='{ is_active:step2.active, is_completed:step2.completed }'> Step 2 </li>
        <li @click='step_three' v-bind:class='{ is_active:step3.active, is_completed:step3.completed }'> Step 3 </li>
      </ul>
    </nav>

    <!-- Return icon -->
    <router-link to="/" class='return-icon'> <i class="icon fas fa-backward return"></i> </router-link>

  </section>
</template>

<script>
import axios from '../../api'

export default {
  data() {
    return {
      // User data
      username: '',
      email: '',
      password: '',
      re_password: '',
      height: '',
      weight: '',
      gender: '',
      age: '',
      experience: '1',
      user_data: [],

      // Response output
      response: '',
      error: false,

      // Progres-bar navigation
      step1: {'active': true,  'completed': false},
      step2: {'active': false, 'completed': false},
      step3: {'active': false, 'completed': false},
    }
  },
  methods: {
    valid_email() {
      // Check if email is taken
      let current_email = this.email
      axios.post('Registration/check_email', {check_email: current_email})
      .then(response => {
        let valid_mail = response.data.check_email
        if(valid_mail !== 'ok'){
          this.response = 'email is not available'
          this.error = true
          return
        } else
          this.error = false
      })
      .catch(e => { this.response = e })

    },
    step_one() {
      this.step1.active = true; this.step2.active = false; this.step3.active = false
      this.step1.completed = false; this.step2.completed = false; this.step3.completed = false
    },
    step_two() {
      this.response = ''
      // Input validation
      if (!this.username.trim() || !this.email.trim() || !this.password.trim() || !this.re_password.trim()) {
        this.response = 'Please fill all the fields'
        return
      }
      if (this.error) {
        this.response = 'Email is already taken'
        return
      }
      if (this.password !== this.re_password) {
        this.response = 'Passwords do not match'
        return
      }
      this.step1.active = false; this.step2.active = true; this.step3.active = false
      this.step1.completed = true; this.step2.completed = false; this.step3.completed = false
      
    },
    step_three() {
      this.response = ''
      if(!this.step1.completed) {
        this.response = 'Please complete STEP 1'
        return // Block jumping from step 1 to step 3
      }
      if (this.height =='' || this.weight =='' || this.gender =='' || this.age =='') {
        this.response = 'Please fill all the fields'
        return
      }
      this.step1.active = false; this.step2.active = false; this.step3.active = true
      this.step1.completed = true; this.step2.completed = true; this.step3.completed = false
    },

    // Send all the user data to backend API
    lets_begin() {
      this.step3.completed = true
      let user_obj = {
        username: this.username,
        email: this.email,
        password: this.password,
        height: this.height,
        weight: this.weight,
        gender: this.gender,
        age: this.age,
        experience: this.experience
      }
      axios.post('Registration/register', {user_obj: user_obj})
      .then(response => {
        this.response = response.data
        // Ako je sve proslo OK - redirekcija na Login page
        if('newUserOK' in response.data) {
          this.$router.push('login')
        }
      })
      .catch(e => { this.response = e })
    },
  }
}
</script>

<style scoped>
  .response {margin-bottom: 5px}
  .hidden {display: none}
  .title {
    margin: 10px 0 30px 0;
    text-transform: uppercase;
    text-align: center;
  }
  .metric-unit {
    display: inline-block;
    font-size: 1.2rem;
    color: #777;
    text-transform: none;
  }

  /*-- For experience tab --*/
  .info {
    margin-left: 30px;
    text-align: start;
    transition: 150ms ease-out;  
  }
  .info:hover {color: #ccc}
  .info p {font-weight: 700; color: var(--main-red-color)}
  .info span { 
    text-transform: none;
    font-size: 1.1rem;
    line-height: 16px;
  }
  .container {
    display: block;
    position: relative;
    padding-left: 35px;
    margin: 0 0 20px 0;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
  }
  /* Hide the browser's default radio button */
  .container input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
  }
  /* Create a custom radio button */
  .checkmark {
    position: absolute;
    top: 50%;
    left: 5%;
    transform: translateY(-50%);
    height: 25px;
    width: 25px;
    background-color: #eee;
    border-radius: 50%;
  }
  /* On mouse-over, add a grey background color */
  .container:hover input ~ .checkmark {
    background-color: #ccc;
  }
  /* When the radio button is checked, add a red background */
  .container input:checked ~ .checkmark {
    background-color: var(--main-red-color);
  }
  /* Create the indicator (the dot/circle - hidden when not checked) */
  .checkmark:after {
    content: "";
    position: absolute;
    display: none;
  }
  /* Show the indicator (dot/circle) when checked */
  .container input:checked ~ .checkmark:after {
    display: block;
  }
  /* Style the indicator (dot/circle) */
  .container .checkmark:after {
    top: 9px;
    left: 9px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: white;
  }



  /*--- PROGRESS NAVIGATION BAR ---*/
  .progres-bar {margin: 80px 0 15px}
  .progres-bar ul {
    display: flex;
    justify-content: space-around;
    text-transform: uppercase;
  }
  .progres-bar li {
    list-style: none;
    cursor: pointer;
    transition: 250ms ease-in-out;
    position: relative;
  }
  /*-- Krugovi --*/
  .progres-bar li::after {
    content: '';
    display: inline-block;
    height: 60px;
    width: 60px;
    background-color: var(--main-bg-color);
    background-position: center center;
    background-repeat: no-repeat;
    border: 2px solid rgb(20, 20, 20);
    border-radius: 50%;
    position: absolute;
    top: -75%;
    left: 50%;
    transform: translate(-50%,-75%);
    transition: 250ms ease-in-out;
    z-index: 100;
  }
  .progres-bar li:hover {color: #ccc}
  .progres-bar li:hover::after {background-color: #2b3033}
  .progres-bar li:nth-child(1)::after {background-image: url('../../assets/images/app/step1.png')}
  .progres-bar li:nth-child(2)::after {background-image: url('../../assets/images/app/step2.png')}
  .progres-bar li:nth-child(3)::after {background-image: url('../../assets/images/app/step3.png')}

  /*-- Linije koje spajaju --*/
  .progres-bar li::before {
    content: '';
    display: inline-block;
    height: 7px;
    width: 180%;
    background-color: rgb(20, 20, 20);
    position: absolute;
    top: -120%;
    left: -180%;
    transform: translateY(-120%);
    z-index: 0;
  }
  .progres-bar li:first-child::before {display: none}
  .progres-bar li.is_active {color: var(--main-red-color); font-weight: 700}
  .progres-bar li.is_active:hover::after {background-color: var(--main-bg-color)}
  .progres-bar li.is_active::after {border-color: var(--main-red-color)}
  .progres-bar li.is_active::before {background-color: #2c662c}
  .progres-bar li.is_completed {color: #ccc}
  .progres-bar li.is_completed::after {border-color: #2c662c}
  .progres-bar li.is_completed:hover::after {background-color: #2b3033}
  .progres-bar li.is_completed::before {background-color: #2c662c}
  .progres-bar li.is_completed::after {background-image: url('../../assets/images/app/ok.png')}

</style>