<template>
  <section class="home">

    <router-link to="/login" class='have-acc'> I already have an account </router-link>

    <Header/>

    <div class="hero">
      <img src="../assets/images/app/bodies.png">
      <p> Let's build your first Gym.ba workout </p>
      <button @click='get_started'> Get started </button>
    </div>

  </section>
</template>

<script>
import Header from '../components/Header'
// import api from '../api'

export default {
  name: 'home',
  components: {
    Header
  },
  data() {
    return {

    }
  },
  methods: {
    get_started() {
      this.$router.push('get_started')
    }
  },
  // mounted() {
  //   axios.post('LoginLogic/login')
  //     .then((res) => {
  //       console.log('Hello response', res)
  //     })
  // }
  
}
</script>

<style scoped>
  .have-acc {
    margin-bottom: 30px;
  }







  /* For large screen */
  @media screen and (min-width: 400px) {
    .mobile-view {display: none}
    .desktop-view { display: block }
    .header {margin-top: 20px}
    .header img {height: 55px;}
  }
</style>