<template>
  <section class="exercises">
      <table class="exercise-list">
        <thead>
          <tr> <th colspan="4"> Choose workout for you </th> </tr>
          <tr>
            <th class="desc">Group</th>
            <th class="desc" colspan="2">Exercise</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(vezba,i) in sve_vezbe" :key='i'>
            <!-- Muscle group image -->
            <td class='muscle-group'> 
              <!-- {{vezba.muscle_group}} -->
              <img :src="vezba.muscle_group_image_link"> 
            </td>
            <!-- Exercise image -->
            <td class='exercise'> 
              <img :src="vezba.exercise_image">
            </td>
            <td> {{vezba.name}} </td>
            <td> <i class="far fa-times-circle icon remove" @click="remove_exercice(i)" title="Remove exercise"></i> </td>
          </tr>
        </tbody>
      </table>

      <!-- {{sve_vezbe}} -->

      <p class="response">{{ response }}</p>
      <p class="info"> number of exercises: {{ sve_vezbe.length }} </p>
      <button @click='start_workout'> Begin workout </button> <br>
      <!-- Return icon -->
      <span class='return-icon' @click='$router.go(-1)'> <i class="icon fas fa-backward return"></i> </span>

      <Footer class='footer'/>
  </section>
</template>

<script>
import store from '../../store'
import Footer from '../../components/Footer'
export default {
  components: {
    Footer
  },
  data() {
    return {
      sve_vezbe: store.state.selected_exercises,
      response: '',
      workout_start: ''
    }
  },
  computed: {
    affected_group() {
      let temporary = []
      let vezbe = this.sve_vezbe
      vezbe.forEach(element => {temporary.push(element.muscle_group)})
      
      let group = []
      temporary.forEach(element => {
        if(!group.includes(element)) group.push(element)
      })
      return group
    }
  },
  methods: {
    remove_exercice(i) {
      this.sve_vezbe.splice(i, 1)
    },
    start_workout() {
      if(this.sve_vezbe.length == 0){
        this.response = 'No exercise selected'
      } else {
        this.workout_time()
        store.commit('ADD_SELECTED_EXERCISES', {vezbe: this.sve_vezbe})
        store.commit('ADD_AFFECTED_MUSCLE_GROUP', {muscle: this.affected_group})
        this.$router.push('start-workout')
      }
    },
    workout_time() {
       let workout_start = new Date()
       localStorage.setItem('workout_start', workout_start)
    }
  }
}
</script>

<style scoped>
  .return-icon {margin-bottom: 50px}
  .exercises {
    min-height: 100vh;
    position: relative;
    padding-bottom: 50px;
  }
  .title {
    text-align: center;
    font-size: 1.3rem;
    margin: 0 0 10px;
  }

  /*--- EXERCISES LIST ---*/
  
  .exercise-list {
    background-color: #00000033;
    width: 95%;
    border-radius: 20px;
    text-align: left;
    padding: 10px;
    margin: 0 auto 25px auto;
  }
  .exercise-list:last-of-type {
    margin-bottom: 0;
  }
  .desc {
    color: #777;
    font-size: 1.1rem;
    margin: 0;
    padding: 0;
  }
  tr:hover {
    background-color: #23282b42;
  }
  th {
    text-transform: uppercase; 
    color: var(--main-red-color);
    font-weight: 700;
    font-size: 1.3rem;
    text-align: center;
    padding-bottom: 15px;
  }
  td:first-of-type img {
    border: 1px solid var(--main-red-color);
  }
  td:first-of-type {
    padding: 7px 0;
  }
  td:nth-child(2) {
    padding-top: 15px;
  }
  td:nth-child(2) img {
    /* border: 1px solid var(--main-red-color); */
    height: 45px;
    width: 45px;
  }
  td:nth-child(3) {
    padding-left: 20px;
  }
  td img {
    transition: 120ms ease-in-out;
    display: block;
    border: 1px solid white;
    border-radius: 50%;
    margin-right: 5px;
    height: 60px;
    width: 60px;
  }
  td:last-of-type {
    text-align: center;
    color: red;
  }
  .remove {
    padding: 7px;
    cursor: pointer;
    color: #777;
    transition: 50ms ease-in-out;
  }
  .remove:hover {
    color: var(--main-red-color);
    transform: scale(1.1);
  }
  button {margin: 0}
  .info {
    color: #777;
    margin-bottom: 7px;
  }



  /* For large screen */
  @media screen and (min-width: 430px) {
    .exercises {
      min-height: 100%;
    }
    .exercise-list {
      padding: 7px;
    }
  }
</style>