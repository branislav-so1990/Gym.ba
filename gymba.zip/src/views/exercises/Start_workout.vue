<template>
  <section class="start-exercise">
  
    <div class="exercises-wrapper" v-if="!last_exercise">
      <div class="exercise-info">
        <div class="left">
          <img :src="current_exercise.muscle_group_image_link">
        </div>
        <div class="right">
          <p class="title"> {{ current_exercise.name }} </p>
          <p class="description"> {{ current_exercise.description }} </p>
          <img :src="current_exercise.exercise_image">
        </div>
      </div>


      <!-- PRIKAZ za REPETITION -->
      <article class="pushups-wrapper e-wrapper" v-if="type == 'repetition'">
        <div class="row-wrapper">
          <div class="set"> Set 1 </div>
          <div class="reps">
            <input type="number" placeholder="enter" v-model="repetition.set1">
            <label> Reps </label>
          </div>
        </div><!-- end of row-wrapper -->

        <div class="row-wrapper">
          <div class="set"> Set 2 </div>
          <div class="reps">
            <input type="number" placeholder="enter" v-model="repetition.set2">
            <label> Reps </label>
          </div>
        </div><!-- end of row-wrapper -->

        <div class="row-wrapper">
          <div class="set"> Set 3 </div>
          <div class="reps">
            <input type="number" placeholder="enter" v-model="repetition.set3">
            <label> Reps </label>
          </div>
        </div><!-- end of row-wrapper -->

        <div class="recommended">
          <!-- <hr>data: {{old_score}} -->
          <p> Last workout: <span>{{ last_exercise_date || 'never'}}</span> </p>
          <p> SET 1: <span>{{ old_score.set1 || 0 }} reps </span> </p>
          <p> SET 2: <span>{{ old_score.set2 || 0 }} reps </span> </p>
          <p> SET 3: <span>{{ old_score.set3 || 0 }} reps </span> </p>
        </div>
      </article>


      <!-- PRIKAZ za RUNNING -->
      <article class="running-wrapper e-wrapper" v-if="type == 'timing'">
        <p class='time' v-if='!stopwatch_started'> {{running.time}} </p>
        <component class='time' :is="dynamic_timer" :date="time_set" v-on:event-child="eventChild"/>

        <div class='stopwatch' v-if="show_start_btn" @click="start_timer">
          <span> Start </span>
          <i class="fas icon fa-stopwatch"></i>
        </div>
        <div class='stopwatch' v-if="show_stop_btn" @click="stop_timer">
          <span> Stop </span>
          <i class="fas icon fa-stopwatch"></i>
        </div>

        <div class="recommended">
          <p> Last workout: <span>{{ last_exercise_date || 'never' }}</span> </p>
          <p v-if="old_score.time"> Previous time: <span> {{old_score.time}} </span> </p>
        </div>
      </article>


      <!-- PRIKAZ sve vezbe WEIGHTS -->
      <article class="reps-weight-wrapper e-wrapper" v-if="type == 'weights'">
        <div class="row-wrapper"><!-- Set 1 -->
          <div class="set"> Set 1 </div>
          <div class="reps">
            <input type="number" placeholder="enter" v-model="weights.set1.reps">
            <label> Reps </label>
          </div>
          <div class="weight">
            <input type="number" placeholder="kg" v-model="weights.set1.weight">
          <label> Weight <span> kg </span> </label>
          </div>
        </div><!-- end of row-wrapper -->

        <div class="row-wrapper"><!-- Set 2 -->
          <div class="set"> Set 2 </div>
          <div class="reps">
            <input type="number" placeholder="enter" v-model="weights.set2.reps">
            <label> Reps </label>
          </div>
          <div class="weight">
            <input type="number" placeholder="kg" v-model="weights.set2.weight"> 
          <label> Weight <span> kg </span> </label>
          </div>
        </div><!-- end of row-wrapper -->
        
        <div class="row-wrapper"><!-- Set 3 -->
          <div class="set"> Set 3 </div>
          <div class="reps">
            <input type="number" placeholder="enter" v-model="weights.set3.reps">
            <label> Reps </label>
          </div>
          <div class="weight">
            <input type="number" placeholder="kg" v-model="weights.set3.weight">
          <label> Weight <span> kg </span> </label>
          </div>
        </div><!-- end of row-wrapper -->

        <div class="recommended">
          <!--<hr>data: {{old_score}} -->
          <p> Last workout: <span>{{ last_exercise_date || 'never'}}</span> </p>
          <p v-for="(score, set) in old_score" :key="set">
            {{ set }}: <span>{{ score.reps || 0 }} x </span> <span>{{ score.weight || 0 }} kg </span> 
          </p>
        </div>
      </article><!-- end of reps-weight-wrapper -->
    </div><!-- end of exercises-wrapper -->

    
    <!-- Prikaz za Exercise completed -->
    <article class="exercise-completed" v-if="last_exercise">
      <p class="stopwatch"> Workout complete! </p>
      <div class="stats">
        <p> Muscle groups affected: 
          <ul class="score">
            <li v-for="(muscle,i) in affected_group" :key="i"><span > {{ muscle }} </span></li>
          </ul>
        </p>
        <p> Exercises completed: <span class="score">{{ max_counter + 1 }}</span> </p>
        <p> Total weight lifted: <span class="score">{{ totalKG }} kg </span> </p>
        <p> Overal workout time: <span class="score"> {{ total_workout_time }} </span> </p>
        <b> Well done! </b>
      </div>
    </article>
    
    <!-- {{affected_muscles}} -->
    
    <p class="response">{{response}}</p>

    <div class="controls">
      <p class="remaining">{{ remaining_exercises }}</p>
      <button v-if="last_exercise" @click='finish_workout'> Finish </button>
      <button v-else @click='next_exercise'> Next exercise</button>
    </div>

  </section>
</template>

<script>
import {bus} from '../../main'
import store from '../../store'
import axios from '../../api'
import Timer from '../../components/Timer'

export default {
  components: {
    Timer
  },
  data() {
    return {
      running: {
        time: '00:00:00'
      },
      repetition: {
        set1: null,
        set2: null,
        set3: null
      },
      weights: {
        set1: {reps: null, weight: null},
        set2: {reps: null, weight: null},
        set3: {reps: null, weight: null}
      },
      totalKG: 0,
      total_run: [],

      // Older score
      old_score: [],
      all_finished_exercises: [],

      // Data for timer
      intID: 0,
      time_set: new Date(),
      time_now: new Date(),
      dynamic_timer: '',

      // Data for score
      counter: 0,
      response: '',
      timer_active: false,
      last_exercise: false,
      stopwatch_started: false,
      show_start_btn: true,
      show_stop_btn: false,
      total_workout_time: null,
      current_exercise: store.state.selected_exercises[0],
      max_counter: store.state.selected_exercises.length -1,
      type: store.state.selected_exercises[0].type_of_exercise,
      affected_muscles: store.state.affected_muscle_group
    }
  },
  methods: {
    session_ref() {
      setTimeout(function(){ 
        axios.post('http://017k122.mars-e1.mars-hosting.com/API/LoginLogic/check_login', {
          sid: window.localStorage.getItem('session-id')
        })
        .then(response => {
          if ('user_data' in response.data) {
            console.log('hej provera')
          } else {
            this.$router.push('/')
          }
        })
        .catch(e => {this.response = e})
      }, 60000)
    },


    //----------- Methods for timer -----------//
    eventChild(id) {this.intID = id},
    start_timer() {
      this.stopwatch_started = true
      this.show_start_btn = false
      this.show_stop_btn = true
      this.dynamic_timer = 'Timer'
      this.time_set = new Date()
      let time_memory = localStorage.getItem('timer')
      if(!time_memory) {
        localStorage.setItem('timer', this.time_set)
      } else {
        this.time_set = new Date(time_memory)
      }
    },
    stop_timer() {
      this.stopwatch_started = false
      this.show_stop_btn = false
      let novoVreme = new Date()
      let memorijaVreme = localStorage.getItem('timer')
      let timePassed = (Math.trunc(novoVreme.getTime()/1000)) - (Math.trunc(new Date(memorijaVreme).getTime()/1000))
      this.running.time = this.hhmmss(timePassed)
      clearInterval(this.intID)
      localStorage.removeItem('timer')
      this.dynamic_timer = ''
    },
    hhmmss(sec){
      var date = new Date(null)
      date.setSeconds(sec)
      var time_string = date.toISOString().substr(11, 8)
      return time_string
    },

    //----------- Methods for exercises -----------//
    next_exercise() {
      this.old_score = []
      var output = null

      if(this.type == 'timing') {
        if(this.input_valid('timing')) {
          this.total_run.push(this.running.time)
          output = this.running
        }
        else return
      }
      if(this.type == 'repetition') {
        if(this.input_valid('repetition'))
          output = this.repetition
        else return
      }
      if(this.type == 'weights') {
        if(this.input_valid('weights')) {
          this.total_weight_lifted()
          output = this.weights
        } else return
      }
      // Send finished exercise result to backend
      axios.post('Workout/exercise_complete', {
        user_id: store.state.user_obj.user_id,
        exercise_id: store.state.selected_exercises[this.counter].id,
        feat: output
      })
      .then(/* for now, no need for response */)
      .catch(e => {this.response = e})

      this.counter++
      this.stopwatch_started = false // Restart the timer
      this.show_start_btn = true
      this.show_stop_btn = false
      this.restart_input()           // Restart input score

      if(this.counter > this.max_counter) {
        this.last_exercise = true
        this.workout_time_stop()
      } else {
        this.get_exercise() // Fetch data for old score if exists
        this.current_exercise = store.state.selected_exercises[this.counter]
        this.type = store.state.selected_exercises[this.counter].type_of_exercise
      }
    },
    input_valid(type) {
      if(type == 'repetition') {
        let set1 = this.repetition.set1
        let set2 = this.repetition.set2
        let set3 = this.repetition.set3
        if(set1==null || set1=='' && set2==null || set2=='' && set3==null || set3=='') {
          if(confirm('No set is entered. Continue?'))
            return true
          else
            return false
        } else
          return true
      }
      else if(type == 'timing') {
        if(this.running.time == '00:00:00'){
          if(confirm('Timer not started. Continue?'))
            return true
          else
            return false
        } else 
          return true
      }
      else if(type == 'weights') {
        let rep1 = this.weights.set1.reps
        let rep2 = this.weights.set2.reps
        let rep3 = this.weights.set3.reps
        let weight1 = this.weights.set1.weight
        let weight2 = this.weights.set2.weight
        let weight3 = this.weights.set3.weight
        
        if((rep1==null || rep1=='' && weight1==null || weight1=='') && (rep2==null || rep2=='' && weight2==null || weight2=='') && (rep3==null || rep3=='' && weight3==null || weight3=='')) {
          if(confirm('No set is entered. Continue?'))
            return true
          else
            return false
        } else
          return true
      }
    },
    get_exercise() {
      axios.post('Workout/get_exercise', {
        user_id: store.state.user_obj.user_id,
        exercise_id: store.state.selected_exercises[this.counter].id,
      })
      .then(response => {
        if('message' in response.data) {
          // this.response = response.data.message
        } else {
          this.old_score = response.data.feats
          this.all_finished_exercises = response.data.exercise
        }
      })
      .catch(e => {this.response = e})
    },

    finish_workout() {
      axios.post('Workout/workout_complete', {
        user_id: store.state.user_obj.user_id,
        total_weight: this.totalKG,
        muscle_groups: this.affected_muscles
      })
      .then(() => {
        bus.$emit('workout-completed')
        this.$router.push('/profile')
      })
      .catch(e => {this.response = e})
    },

    workout_time_stop() {
      let time_now = new Date()
      let time_start = localStorage.getItem('workout_start')
      let workout_time = (Math.trunc(time_now.getTime() / 1000)) - (Math.trunc(new Date(time_start).getTime() / 1000))
      this.total_workout_time = this.hhmmss(workout_time)
    },
    restart_input() {
      this.running = {
        time: '00:00:00'
      }
      this.repetition = {
        set1: null,
        set2: null,
        set3: null
      }
      this.weights = {
        set1: {reps: null, weight: null},
        set2: {reps: null, weight: null},
        set3: {reps: null, weight: null}
      }
    },
    total_weight_lifted() {
      let rep1 = parseInt(this.weights.set1.reps)
      let rep2 = parseInt(this.weights.set2.reps)
      let rep3 = parseInt(this.weights.set3.reps)

      let weight1 = parseInt(this.weights.set1.weight)
      let weight2 = parseInt(this.weights.set2.weight)
      let weight3 = parseInt(this.weights.set3.weight)

      // ako je neki rep ostao prazan
      isNaN(rep1) ? rep1=0 : rep1
      isNaN(rep2) ? rep2=0 : rep2
      isNaN(rep3) ? rep3=0 : rep3

      // ako je neki set ostao prazan
      isNaN(weight1) ? weight1=0 : weight1
      isNaN(weight2) ? weight2=0 : weight2
      isNaN(weight3) ? weight3=0 : weight3

      this.totalKG += (rep1*weight1) + (rep2*weight2) + (rep3*weight3)
    }
  },
  computed: {
    last_exercise_date() {
      return this.all_finished_exercises.date
    },
    sve_vezbe() {
      return store.state.selected_exercises
    },
    remaining_exercises() {
      let total = store.state.selected_exercises.length
      let current = this.counter + 1
      if(current > total) return 'End of workout'
      else return 'Exercise ' + current + ' of ' + total
    },
    affected_group() {
      let workedout = []
      let muscles = ['None', 'Abs', 'Legs', 'Lower back', 'Biceps', 'Shoulders', 'Chest', 'Back', 'Triceps', 'Hamstrings', 'Cardio']
      this.affected_muscles.forEach(i => {
        workedout.push( muscles[i] )
      });
      return workedout
    }
  },
  mounted() {
    this.get_exercise()
    this.session_ref()
  }
  
}
</script>

<style scoped>
  .start-exercise {
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
  }
  .title {
    text-align: center;
    font-size: 1.2rem;
  }
  .description {
    color: #777;
  }
  .exercise-info {
    /* border: 1px dashed white; */
    margin-bottom: 7px;
    display: flex;
  }
  .left img {
    border: 2px solid var(--main-red-color);
    border-radius: 50%;
    height: 130px;
    display: block;
    object-fit: cover;
    margin: 15px 5px 0 10px;
  }
  .right {
    /* border: 1px dashed white; */
    width: 60%;
    padding-top: 10px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  .right img {
    display: block;
    height: 100px;
    width: 100px;
    margin: 0 auto;
  }


  .e-wrapper {
    margin-top: 35px;
  }
  .row-wrapper {
    /* border: 1px dashed red; */
    display: flex;
    justify-content: center;
    padding-right: 15px;
  }
  .set {
    width: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-transform: uppercase;
    font-weight: 700;
    font-size: 1.2rem;
    color: var(--main-red-color);
  }
  label {
    margin: 0;
    font-weight: 700;
    color: #777;
  }
  label span {color: #777}
  input {
    margin-bottom: 3px;
    font-size: 1.7rem;
    max-width: 150px;
  }
  input::placeholder {font-size: 1.5rem}
  button {
    margin: 5px;
    margin-bottom: 0;
  }

  .time {
    margin: 30px auto;
    font-size: 3.5rem;
    border: none;
    /* border: 1px dashed white; */
    width: 300px;
    padding: 0px;
  }
  .stopwatch {
    font-size: 1.4rem;
    border-bottom: 2px solid #777;
    display: inline-block;
    padding: 8px 15px;
    color: #777;
    cursor: pointer;
    transition: 100ms ease-in-out;
  }
  .stopwatch:hover {
    color: #ccc;
    font-weight: 700;
    border-color: var(--main-red-color);
  }
  .stopwatch:hover .icon{
    font-size: 1.5rem;
    opacity: 0.8;
  }
  .icon {transition: 100ms ease-in-out;}
  .remaining {
    color: #777;
    font-weight: 700;
  }
  .controls {
    /* border: 1px dashed white; */
  }
  .exercise-completed {
    padding: 15px;
  }
  .exercise-completed .stopwatch {
    color: #fff;
    font-weight: 700;
    border-color: var(--main-red-color);
  }
  .stats {
    /* border: 1px dashed white; */
    margin-top: 15px;
    text-align: left;
    font-size: 1.2rem;
    color: #9e9e9e;
  }
  .stats ul li {
    margin-left: 20px;
  }
  .stats b {
    display: inline-block;
    margin-top: 50px;
    font-size: 1.4rem;
    color: var(--main-red-color);
  }
  .score {
    color: #fff;
    font-size: 1.4rem;
    margin-bottom: 20px;
  }
  .return-icon {
    border: 1px solid red;
  }
  .recommended {
    color: #777;
    margin-top: 25px;
  }
  .recommended span {
    color: #ccc;
    margin-left: 5px;
  }


  /* For large screen */
  @media screen and (min-width: 430px) {
    .start-exercise {
      min-height: 100%;
    }
  }
</style>