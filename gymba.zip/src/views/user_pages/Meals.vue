<template>
  <section class="meals-page">
    <p class="title"> Tasty and delicios </p>
    <p class="subtitle"> What's your favourite </p>

    <div class="meals-wrapper">
      <article class="one-meal" v-for="meal in meals" :key="meal.id" @click="get_recepie(meal.id)">
        <div class="picture-frame">
          <img :src="meal.image_link">
        </div>
        <p> {{ meal.name }} </p>
      </article>
    </div>

    <p class="response">{{ response }}</p>

    <!-- Return icon -->
    <span class='return-icon' @click='$router.go(-1)'> <i class="icon fas fa-backward return"></i> </span>

    <Footer class='footer'/>
  </section>
</template>

<script>
import axios from '../../api'
import Footer from '../../components/Footer'
export default {
  props: [
    'category_id'
  ],
  components: {
    Footer
  },
  data() {
    return {
      id: this.category_id,
      meals: [],
      response: ''
    }
  },
  methods: {
    get_recepie(meal_id) {
      this.$router.push('/recepie/' + meal_id)
    }
  },
  computed: {
    
  },
  created() {
    axios.post('Nutrition/get_all_from_category', {
      category_id: this.id
    })
    .then(response => {
      if('meals' in response.data) {
        this.meals = response.data.meals
      } else
        this.response = response.data.error
    })
    .catch(e => {this.response = e})
  }
}
</script>

<style scoped>
  
  .meals-page {
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
    /* border: 1px dashed white; */
  }
  .title {
    text-align: center;
    font-size: 1.5rem;
  }
  .subtitle {
    display: inline-block;
    font-size: 1.1rem;
    text-transform: uppercase;
    color: #777;
    font-weight: 700;
    position: relative;
    margin-bottom: 15px;
  }
  .subtitle::before,
  .subtitle::after {
    content: '';
    display: inline-block;
    height: 1px;
    width: 100%;
    background-color: #777;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
  }
  .subtitle::before {left: -105%}
  .subtitle::after {right: -105%}


  /*--- Meals ---*/
  .meals-wrapper {
    /* border: 1px dashed white; */
    display: flex;
    flex-wrap: wrap;
    justify-content: space-evenly;
  }
  .one-meal {
    height: 200px;
    width: 150px;
    border-radius: 8px;
    margin: 5px;
    border: 1px solid var(--main-bg-color);
    background-color: #fff;
    color: var(--main-font-color);
    position: relative;
    transition: 250ms ease-in-out;
    cursor: pointer;
    padding: 7px;
    overflow: hidden;
  }
  .picture-frame {
    border-radius: 5px;
    height: 100%;
    position: relative;
    overflow: hidden;
  }
  .one-meal img {
    margin: auto;
    height: 100%;
    min-width: 100%;
    display: block;
    transition: 250ms ease-in-out;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
  }
  .one-meal p {
    font-size: 1.2rem;
    min-width: 140px;
    max-width: 150px;
    font-weight: 700;
    text-transform: uppercase;
    transition: 550ms ease-in-out;
    position: absolute;
    bottom: 10%;
    left: 50%;
    transform: translateX(-50%);
    text-shadow: 2px 2px 2px rgb(0, 0, 0);
  }
  .one-meal:hover {
    border: 0;
    padding: 0;
    /* border-radius: 0; */
    box-shadow: 0px 0px 6px 0px rgba(194,194,194,1);
  }
  .one-meal:hover p {bottom: -100%}
  .one-meal:hover .picture-frame {border-radius: 0;}
  .one-meal:last-of-type{margin-bottom: 0px;}

  /* For large screen */
  @media screen and (min-width: 430px) {
    .meals-page {
      min-height: 100%;
      padding-bottom: 60px;
    }
    
  }
</style>