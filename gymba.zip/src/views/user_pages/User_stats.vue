<template>
  <section class="user-stats">
    
    <p class="user-name"> Personal stats:  </p>
    <p class="title"> <i class="fas fa-user icon"></i> {{ user.username }}</p>

    <ul>
      <li> Age: <span>{{ user.age }}</span> </li>
      <li> Gender: <span>{{ user.gender }}</span> </li>
      <li> Experience: <span>{{ level }}</span> </li>
      <li> BMI: <span>{{ user.bmi }}</span> </li>
      <li> Height: <span>{{ user.height }}cm </span> </li>
      <li> Weight: <span>{{ user.weight }}kg </span> </li>
    </ul>

    <!-- Return icon -->
    <span class='return-icon' @click='$router.push("/profile")'> <i class="icon fas fa-backward return"></i> </span>
    <Footer class='footer'/>
  </section>
</template>

<script>
import store from '../../store'
import Footer from '../../components/Footer'

export default {
  components: {
    Footer
  },
  data() {
    return {
      
    }
  }, 
  computed: {
    user() {
      let data = {
        user_id: store.state.user_obj.user_id,
        username: store.state.user_obj.username,
        gender: store.state.user_obj.gender,
        age: store.state.user_obj.age,
        bmi: store.state.user_obj.bmi,
        weight: store.state.user_obj.weight,
        height: store.state.user_obj.height,
        body_fat: store.state.user_obj.body_fat,
      }
      return data
    },
    level() {
      let level = store.state.user_obj.level
      switch(level) {
        case 1:
          level = 'Beginer'
          break 
        case 2:
          level = 'Intermediate'
          break 
        case 3:
          level = 'Advanced'
          break 
      }
      return level
    }
  }
}
</script>

<style scoped>
  .user-stats {
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
    padding-bottom: 60px;
  }
  .title {
    font-size: 1.6rem;
    text-align: center;
    text-transform: none;
    margin: 7px 0 30px;
  }
  .title .icon {
    font-size: 1.3rem;
  }
  .user-name {
    font-size: 1.4rem;
    border-bottom: 2px solid #777;
    display: inline-block;
    padding: 8px 15px;
    color: #777;
    transition: 100ms ease-in-out;
  }
  ul {
    width: fit-content;
    margin: 0 auto;
    text-align: left;
    font-size: 1.2rem;
    margin-bottom: 50px;
  }
  li {
    list-style: none;
    color: #777;
  }
  li span {
    color: #ccc;
  }



  /* For large screen */
  @media screen and (min-width: 430px) {
    .user-stats {
      min-height: 100%;
      /* padding-bottom: 100px; */
    }
  }
</style>