<template>
  <section class="nutrition-page">
    <h3 class="title"> Healthy nutrition meals </h3>
    <p class="subtitle"> Choose category </p>
    
    <article class="category-wrapper">
      <div class="one-category" v-for='category in categories' :key='category.id' @click="go_to_meals(category.id)">
        <p>{{ category.name }}</p>
        <img :src="category.image">
      </div>
    </article><!-- end of wrapper -->

    <p class="response">{{ response }}</p>

    <Footer class='footer'/>
  </section>
</template>

<script>
import axios from '../../api'
import Footer from '../../components/Footer'
export default {
  components: {
    Footer
  }, 
  data() {
    return {
      categories: [],
      response: ''
    }
  },
  methods: {
    get_categories() {
      axios.get('Nutrition/show_categories')
      .then(response => {
        if ('error' in response.data)
          this.response = response.data.error
        else
          this.categories = response.data.show_category
      })
      .catch(e => {
        this.response = e
      })
    },
    go_to_meals(category_id) {
      this.$router.push('/meals/' + category_id)
    },
  },
  beforeMount() {
    this.get_categories()
  }
}
</script>

<style scoped>
  .nutrition-page {
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
  }
  .title {
    text-align: center;
    font-size: 1.5rem;
  }
  .subtitle {
    display: inline-block;
    font-size: 1.1rem;
    text-transform: uppercase;
    color: #777;
    font-weight: 700;
    position: relative;
    margin-bottom: 15px;
  }
  .subtitle::before,
  .subtitle::after {
    content: '';
    display: inline-block;
    height: 1px;
    width: 100%;
    background-color: #777;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
  }
  .subtitle::before {left: -105%}
  .subtitle::after {right: -105%}

  /*-- Category --*/
  .category-wrapper {
    /* border: 1px dashed white; */
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }
  .one-category {
    height: 150px;
    width: 150px;
    border-radius: 20px;
    margin: 5px;
    border: 1px solid var(--main-bg-color);
    background-color: #ffffff10;
    color: var(--main-font-color);
    position: relative;
    transition: 250ms ease-in-out;
    cursor: pointer;
    overflow: hidden;
  }
  .one-category p {
    text-transform: uppercase;
    font-weight: 700;
    line-height: 250px;
    transition: 130ms ease-in-out;
  }
  .one-category img {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    display: block;
    transition: 250ms cubic-bezier(.85,1.84,.87,1.4);
  }
  .one-category:hover {
    background-color: var(--main-bg-color);
    border-color: var(--main-red-color);
  }
  .one-category:hover img, 
  .one-category:hover p {
    transform: scale(1.2);
    text-transform: none;
  }




  /* For large screen */
  @media screen and (min-width: 430px) {
    .nutrition-page {
      min-height: 100%;
      width: 100%;
      padding-bottom: 60px;
    }
    
  }
</style>