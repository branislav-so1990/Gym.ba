<template>
  <section class="workout-page">

    <div class="workout-plans" v-for="workout in workouts" :key="workout.id" @click="toggle(workout.id)">
      <div class="header">
        <img class="picture" :src="workout.image_link"> {{workout.image_link}}
        <span class="title"> {{workout.name}} </span>
      </div>

      <div class="wo-desc" :class="[workout.id==id ? open : '']">
        <ul>
          <li @click="get_workout_plan(workout.id, i)" v-for="(exercise, i) in workout.description" :key="i" :class="{ rest: exercise == 'Rest' }">
            <i class="icons fas fa-heartbeat" v-if="exercise == 'Rest'"></i>
            <i class="icons fas fa-dumbbell" v-else></i>
            Day {{i}}: {{exercise}}
          </li>
        </ul>
      </div>

    </div>
    
    <!-- <p class="response">{{output}}</p> -->
    <Footer class='footer'/>

  </section>
</template>

<script>
import axios from '../../api'
import Footer from '../../components/Footer'
import store from '../../store'
import check_login from '../../assets/mixins/check_login'

export default {
  mixins: [check_login],
  components: {
    Footer,
  },
  data() {
    return {
      id: null,
      workouts: [],
      bool: true,
      output: '',
      time: new Date(),
      open: 'open'
    }
  },
  created() {
    this.get_workouts()
  },
  methods: {
    // Get all exercises for specific workout
    get_workout_plan(plan_id, day) {
      axios.post('WorkoutPlan/show_exercises', {day: day, plan_id: plan_id})
      .then(response => {
        let temp = response.data.exercise_list
        let chosed_exercises = []
        for(var i in temp) {
          chosed_exercises.push(temp[i].exercise_for_image)
        }
        store.commit('ADD_SELECTED_EXERCISES', {vezbe: chosed_exercises})
        this.$router.push('/exercises')
      })
      .catch(e => { this.output = e })
    },
    toggle(id) {
      this.bool = !this.bool
      this.id = id
    },
    get_workouts() {
      // Get all predef workout plans
      axios.post('WorkoutPlan/workout_plans')
      .then(response => {
        this.workouts = response.data.workout_plans
        for (let i in this.workouts) {
          this.workouts[i].description = JSON.parse(this.workouts[i].description)
        }
      })
      .catch(e => { this.output = e })
    },
  },
  mounted() {
    this.check_loged()
  }
}
</script>

<style scoped>
  .workout-page {
    min-height: 100vh;
    position: relative;
    padding-bottom: 60px;
  }
  .workout-plans {
    margin-bottom: 10px;
    min-height: 150px;
    transition: 450ms ease-in-out;
  }
  .header {
    /* border: 1px dashed white; */
    border-radius: 10px;
    height: 160px;
    padding: 20px 15px;
    text-align: left;
    position: relative;
    z-index: 0;
    cursor: pointer;
  }
  .title {
    font-weight: 700;
    transition: 250ms ease-in-out;
    color: #ccc;
    display: block;
    white-space: pre-line;
  }
  .picture{
    border-radius: 10px;
    position: absolute;
    display: block;
    top: 0;
    left: 0;
    width: 100%;
    object-fit: cover;
    height: 160px;
    z-index: -50;
    opacity: 0.5;
    transition: 250ms ease-in-out;
  }
  .workout-plans:hover .picture {
    opacity: 0.9;
  }
  .workout-plans:hover .title {
    color: #fff;
    text-shadow: 2px 2px 4px #000000;
  }
  .workout-plans:hover .wo-desc {
    color: #ccc;
  }
  .wo-desc {
    /* border: 1px solid #ccc;
    border-top: none; */
    border-radius: 0 0 15px 15px;
    color: #777;
    padding: 0px 15px;
    max-height: 0;
    overflow: hidden;
    transition: 0.3s ease all;
    transition-property: max-height;
    text-align: left;
  }
  li {
    list-style-type: none;
    padding: 3px;
    cursor: pointer;
    transition: 100ms ease-in-out;
    font-size: 1.1rem;
  }
  li:hover {
    background-color: var(--main-bg-color);
  }
  li::after {
    content: '- Go!';
    color: var(--main-red-color);
    opacity: 0;
    transition: 200ms ease-in-out;
  }
  li:hover::after {
    display: inline-block;
    opacity: 1;
  }
  .is-closed, .open {
    max-height: 20em;
    overflow: hidden;
  }
  .icons {
    font-size: 1.1rem;
    margin-right: 5px;
    min-width: 25px;
    text-align: center;
  }
  .rest {
    /* text-decoration: line-through; */
    pointer-events: none;
  }
  .fa-heartbeat {
    color: var(--main-red-color);
    opacity: 0.9;
  }

  /* For large screen */
  @media screen and (min-width: 430px) {
    .workout-page {
      min-height: 100%;
      padding-bottom: 60px;
    }
  }
</style>