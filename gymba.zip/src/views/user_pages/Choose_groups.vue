<template>
  <section class="choose-group">
    <p class="title"> Pick the muscle group you want to work out: </p>
    <p class="subtitle"> Main muscle groups </p>
    
    <article class="muscle-groups">
      <label v-for="muscle_group in muscle_groups" :key="muscle_group.id">
        <input type="checkbox" :value="muscle_group.id" v-model="checkedMuscles">
        <img :src="muscle_group.image_link"> 
        <span class='description'> {{ muscle_group.name }} </span>
      </label>
    </article>

    <p class='info'> Selected {{checkedMuscles.length}} </p>

    <button @click='find_exercises' :class="{ disabled: checkedMuscles.length == 0 }"> Search exercises </button>
    <p class="response"> {{response}} </p>
    
    <Footer class='footer'/>
  </section>
</template>

<script>
import store from '../../store'
import axios from '../../api'
import Footer from '@/components/Footer'
export default {
  components: {
    Footer
  },
  data() {
    return {
      // All muscle groups
      muscle_groups: [],
      // What user selected
      checkedMuscles: [],
      // What backend result found
      found_exercises: [],
      // Output
      response: ''
    }
  },
  methods: {
    show_all_muscle_groups() {
      axios.get('show_muscle_group')
      .then(response => {this.muscle_groups = response.data.muscle_groups})
      .catch(e => { this.response = e })
    },

    find_exercises() {
      axios.post('choose_group_exercise', { choose_groups: this.checkedMuscles })
      .then(response => {
        this.found_exercises.push(response.data.exercises)
        store.commit('ADD_SELECTED_EXERCISES', {vezbe: response.data.exercises})
        this.$router.push('exercises')
      })
      .catch(e => { this.response = e })
    },

    clear_old_exercises() {store.commit('CLEAR_SELECTED_EXERCISES') },
    clear_affected_musles() {store.commit('CLEAR_AFFECTED_MUSCLE_GROUP') },
  },
  mounted() {
    this.show_all_muscle_groups(),
    this.clear_old_exercises()
    this.clear_affected_musles()
  }
}
</script>

<style scoped>
  button.disabled {
    background-color: var(--main-bg-color);
    border-color: #777;
    color: #777;
    pointer-events: none;
  }
  .choose-group {
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
  }
  .title {
    padding: 0 20px;
    font-size: 1.3rem;
    margin: 0 0 15px;
    text-align: center;
  }
  .subtitle {
    display: inline-block;
    font-size: 1.1rem;
    text-transform: uppercase;
    color: #777;
    font-weight: 700;
    position: relative;
    margin-bottom: 15px;
  }
  .subtitle::before,
  .subtitle::after {
    content: '';
    display: inline-block;
    height: 1px;
    width: 100%;
    background-color: #777;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
  }
  .subtitle::before {left: -105%}
  .subtitle::after {right: -105%}



  .muscle-groups {
    /* border: 1px dashed white; */
    height: fit-content;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-evenly;
  }
  .muscle-groups label {
    border: 1px solid #b9b9b9;
    border-radius: 50%;
    height: 100px;
    width: 100px;
    margin: 0 5px 40px;
    position: relative;
    transition: 200ms ease-in-out;
    cursor: pointer;
    background-color: rgb(31, 31, 31);;
  }
  .muscle-groups label:hover {
    border-color: var(--main-red-color);
    background-color: var(--main-bg-color);
  }
  .muscle-groups span {opacity: 0.6}
  .muscle-groups img {
    height: 99%;
    width: 99%;
    opacity: 0.3;
  }
  .description {
    /* border: 1px dashed white; */
    min-width: 128%;
    position: absolute;
    bottom: -30px;
    left: 50%;
    transform: translateX(-50%);
    font-weight: 700;
    font-size: 1.1rem;
    transition: 200ms ease-in-out;
  }
  input[type='checkbox'] {display: none}
  input[type='checkbox']:checked ~ img{opacity: 1}
  input[type='checkbox']:checked ~ span {
    color: var(--main-red-color);
    opacity: 1;
  }
  .info {
    color: #777;
    font-weight: 700;
    margin: 20px 0 5px;
  }
  button {margin: 0}
  .response {
    margin: 5px 0 55px 0;
    height: 0px;
    padding: 0;
  }
  

  /* For large screen */
  @media screen and (min-width: 430px) {
    .choose-group {
      min-height: 100%;
    }
  }
</style>