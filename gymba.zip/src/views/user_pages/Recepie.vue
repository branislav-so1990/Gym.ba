<template>
  <section class="recepie-page">
    <p class="title"> {{ meal.name }} </p>

    <div class="header">
      <img :src="meal.image_link">
    </div>
    
    <div class="wrapper">
      <p class='subtitle'> Ingridients: </p>
      <p>{{ meal.ingredients }}</p>

      <p class="subtitle"> Instructions: </p>
      <p>{{ meal.preparation }}</p>
      <span> Bon apettit! </span>
    </div>

    <p class="response">{{ response }}</p>
    
    <!-- Return icon -->
    <span class='return-icon' @click='$router.go(-1)'> <i class="icon fas fa-backward return"></i> </span>
    
    <Footer class='footer'/>
  </section>
</template>

<script>
import axios from '../../api'
import Footer from '../../components/Footer'

export default {
  props: [
    'meal_id'
  ],
  components: {
    Footer
  },
  data() {
    return {
      id: this.meal_id,
      meal: [],
      response: ''
    }
  },
  created() {
    axios.post('Nutrition/get_meal', {meal_id: this.id})
    .then(response => {
      if('meal' in response.data) 
        this.meal = response.data.meal
      else
        this.response = response.data.error
    })
    .catch(e => {this.response = e})
  }
}
</script>

<style scoped>
  .recepie-page {
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
  }
  .title {
    text-align: center;
    font-size: 1.3rem;
  }
  .subtitle {
    /* text-align: center; */
    text-transform: uppercase;
    font-size: 1.2rem;
    font-weight: 700;
    color: var(--main-red-color);
    margin: 15px 0 7px;
  }
  .subtitle:last-of-type {margin-top: 15px}
  .description {
    font-size: 1.2rem;
    color: #ccc;
  }
  .header {
    display: flex;
    justify-content: center;
    margin: 10px 0;
  }
  .header img {
    max-width: 75%;
    border-radius: 10px;
    display: inline-block;
  }
  .header p {
    padding-left: 10px;
    text-align: left;
  } 
  .wrapper {
    text-align: left;
    padding-left: 5px;
    white-space: pre-line;
  }
  ul, ol {padding-left: 20px}
  span {
    /* text-align: center; */
    display: block;
    color: var(--main-red-color);
    margin: 10px 0 0px;
    font-size: 1.1rem;
  }
  .return-icon {margin: 0 0 60px}




  /* For large screen */
  @media screen and (min-width: 430px) {
    .recepie-page {
      min-height: 100%;
    }
    
  }
</style>