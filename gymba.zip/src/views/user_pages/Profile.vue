<template>
  <section class="profile-page">

    <header class="user-nav">
      <p class="title">{{ username }}</p>
      
      <nav class="navigation">
        <span class='hamburger' v-bind:class='{ active : menu_opened }' @click='menu_opened = !menu_opened'> &#9776; </span>
        <ul class="drop-down" v-bind:class='{ closed : !menu_opened }'>
          <li @click='$router.push("/user-stats")'> User stats <i class="fas fa-chart-line icon"></i> </li>
          <li @click='log_out'> Sign out <i class="fas fa-sign-out-alt icon sign-out"></i> </li>
        </ul>
      </nav>

      <div class="info fresh-muscles">
        <span class="number"> {{fresh_muscles}} </span>
        <span>Fresh muscle <br> groups</span>
      </div>

      <div class="since-workout">
        <span class="number">{{ since_last_workout }} </span>
        <p> days since <br> last workout</p>
      </div>
    </header>
    
    <!-- <p> radjeni misici (computed): <br> {{affected_muscle}} </p> -->

    <!-- User body picture -->
    <div class="body-pic">
      <div class="body-wrapper" v-bind:class='{ rotated : is_rotated }'>

        <div v-if="gender == 'male'">
          <div v-for="(muscle,i) in affected_muscle" :key="i">
            <img :src="'/profile-body/male/' + muscle + '.png'" :class="muscle" class="addon">
          </div>
          <!-- Normal body -->
          <img class="front-face" src="../../assets/images/app/profile-bck-front.png">
          <img class="back-face" src="../../assets/images/app/profile-bck-back.png">
        </div>

        <div v-else-if="gender == 'female'">
          <div v-for="(muscle,i) in affected_muscle" :key="i">
            <img :src="'/profile-body/female/' + muscle + '.png'" :class="muscle" class="addon">
          </div>
          <!-- Normal body -->
          <img class="front-face" src="../../assets/images/app/profile-bck-front-female.png">
          <img class="back-face" src="../../assets/images/app/profile-bck-back-female.png">
        </div>
      </div>
      <i class="fas fa-street-view rotate-icon" @click='is_rotated = !is_rotated'></i>
    </div>
    
    <p class="rested" v-if="is_rested"> You feel <br> rested </p>

    <!-- odmoran: {{is_rested}} <br>
    radjeni misici: {{muscles}} <br> -->
    <p class="response">{{ response }}</p>
    
    <Footer class='footer'/>
  </section>
</template>

<script>
import {bus} from '../../main'
import axios from '../../api'
import store from '../../store'
import Footer from '@/components/Footer'
export default {
  components: {
    Footer
  },
  data() {
    return {
      // user data from store
      is_loged: false,
      user_id: null,
      username: null,
      gender: null,
      level: null,
      age: null,
      bmi: null,
      weight: null,
      height: null,
      body_fat: null,

      // picture animation
      is_rotated: false,
      menu_opened: false,

      // About last workout
      since_last_workout: null,
      muscles: [],
      is_rested: false,

      // output
      response: ''
    }
  },
  methods: {
    check_if_loged() {
      axios.post('LoginLogic/check_login', {
        sid: window.localStorage.getItem('session-id')
      })
      .then(response => {
        if ('user_data' in response.data) {
          // Send user data localy
          let user =  response.data.user_data.stats
          this.username = response.data.user_data.data.username
          this.user_id = user.user_id
          this.gender = user.gender
          this.level = user.training_level
          this.age = user.age
          this.bmi = user.bmi
          this.height = user.height
          this.weight = user.weight
          this.body_fat = user.body_fat
          this.last_workout_info()

          // Send user data to store 
          store.commit('SET_USER_LOGED', {
            username: response.data.user_data.data.username,
            user_id: user.user_id,
            gender: user.gender,
            level: user.training_level,
            bmi: user.bmi,
            age: user.age,
            height: user.height,
            weight: user.weight,
            body_fat: user.body_fat
          })
        } else
          this.$router.push('/login') // Not loged in
      })
      .catch(e => {this.response = e}) 
    },
    
    log_out() {
      axios.post('LoginLogic/logout', {
        sid: window.localStorage.getItem('session-id')
      })
      .then(response => {
        store.commit('SET_USER_LOGEDOUT')
        window.localStorage.removeItem('session-id')
        window.localStorage.removeItem('vuex')
        this.response = response.data
        this.$router.push('/')
			})
			.catch((e) => {this.response = e})
    },

    last_workout_info() {
      axios.post('Workout/get_last_workout', {user_id: this.user_id})
      .then(response => {
        // If user has never finished workout
        if(response.data.Status == 'No workouts completed') {
          this.since_last_workout = '-'
        } else {
          this.since_last_workout = response.data.this_date
        }
        this.muscles = response.data.muscle_groups // Last worked muscle group
        if(this.since_last_workout > 0) {
          this.is_rested = true
          this.muscles = []
        }
      })
      .catch(e => {this.response = e})
    }
  },
  computed: {
    fresh_muscles() {
      let worked_muscles = this.muscles || []
      let total = 9 // Number of muscle groups
      return total - worked_muscles.length
    },
    affected_muscle() {
      let worked_muscles = this.muscles || []
      let groups = ['none', 'abs', 'legs', 'lower back back-face', 'biceps', 'shoulders', 'chest', 'back back-face', 'triceps back-face', 'hamstrings', 'cardio']

      let muscle_names = []
      worked_muscles.forEach(e => {
        muscle_names.push(groups[e])
      });
      if(muscle_names.includes('shoulders')) 
        muscle_names.push('shoulders back-face')
      if(muscle_names.includes('legs')) 
        muscle_names.push('legs back-face')
      if(muscle_names.includes('cardio')) 
        muscle_names.push('cardio back-face')
      
      return muscle_names
    }
  },
  beforeMount() {
    this.check_if_loged()
  },
  mounted() {
    bus.$on('user-edited', () => {this.check_if_loged()})
  }
}
</script>

<style scoped>
  .profile-page {
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
    padding-bottom: 60px;
  }
  .info {
    position: absolute;
    top: 40px;
    left: 5px;
    text-transform: uppercase;
    font-size: 0.9rem;
    color: #777;
  }
  .number {
    font-family: 'Arial Narrow', Arial, sans-serif;
    font-size: 3rem;
    font-weight: 400;
    display: block;
    color: #ccc;
  }
  .since-workout {
    position: absolute;
    top: 40px;
    right: 5px;
    text-transform: uppercase;
    font-size: 0.9rem;
    color: #777;
  }
  .user-nav {
    margin-bottom: 10px;
    height: 33px;
    margin-bottom: 40px;
  }
  .title {
    text-align: center;
  }
  .navigation {
    position: relative;
    top: -30px;
    right: 0;
    text-align: right;
    z-index: 500;
    transition: 250px ease-in-out;
  }
  .drop-down {
    border-top: 1px solid var(--main-red-color);
    background-color: var(--main-bg-color);
    border-bottom-left-radius: 15px;
    position: absolute;
    right: 0;
    top: 35px;
    transition: 500ms cubic-bezier(.75,1.89,.86,.7);
    
  }
  li {
    list-style: none;
    padding: 7px 10px;
    cursor: pointer;
    color: #9b9b9b;
    font-size: 1.2rem;
    transition: 150ms ease-in-out;
  }
  li:last-child {border-bottom-left-radius: 15px}
  li:hover {
    background-color: #ffffff0d;
    color: #ccc;
  }
  .icon {
    color: #ccc;
    transition: 150ms color ease-in-out;
  }
  li:hover .icon {
    transform: scale(1.1);
    color: var(--main-red-color);
  }
  
  .hamburger {
    cursor: pointer;
    transition: 250ms ease-in-out;
    font-size: 1.5rem;
    padding: 5px;
  }
  .hamburger:hover {color: #ccc}
  .hamburger.active {color: var(--main-red-color)}
  .drop-down.closed {right: -100%}



  .body-pic {
    /* border: 1px dashed white; */
    width: 74%;
    margin: 0 auto;
    height: fit-content;
  }
  .body-wrapper {
    /* border: 1px solid red; */
    transition: transform 0.8s;
    transform-style: preserve-3d;
  }
  .front-face {
    position: relative;
  }
  .front-face, .back-face {
    width: 100%;
    display: block;
    backface-visibility: hidden;
    border: 1px solid #ffffff00;
  }
  .back-face {
    transform: rotateY(180deg);
    position: absolute;
    top: 0;
    left: 0;
  }
  .rotate-icon:hover {color: #ccc}
  .rotate-icon {
    font-size: 1.8rem;
    position: absolute;
    left: 10px;
    bottom: 60px;
    cursor: pointer;
    color: #777;
    transition: 200ms ease-in-out;
  }
  .rotated.body-wrapper {transform: rotateY(180deg)}

  .addon {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 500;
  }
  .rested {
    color: green;
    font-weight: 700;
    position: absolute;
    bottom: 60px;
    right: 10px;
  }


  
  




  /* For large screen */
  @media screen and (min-width: 430px) {
    .profile-page {
      min-height: 100%;
      /* padding-bottom: 100px; */
    }
  }
</style>