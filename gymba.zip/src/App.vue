<template>
  <div class="app">

    <!-- MOBILE VIEW -->
    <div class="mobile-view"> 
      <router-view/>
    </div>

    <!-- <span style="background:black">{{user_status}}</span> -->

    <!-- DESKTOP APP VIEW -->
    <div class="desktop-view">

      <!-- Mobile screen left-side -->
      <div class="phone-wrapper">
        <img class="phone-case" src="@/assets/images/app/phone-case.png">
        <Clock/>
        <div class="phone-screen">
          <router-view/>
        </div>
        <router-link to="/"> <i class="far fa-circle home-btn"></i> </router-link>
      </div>

      <!-- Desctop screen right-side -->
      <div class="desktop-screen">
        <Desktop/>
      </div>

    </div><!-- end of desktop view -->
    
  </div>
</template>

<script>
import axios from './api'
import Desktop from './components/Desktop'
import Clock from './components/Clock'
import store from './store'

export default {
  components: {
    Desktop,
    Clock
  },
  data() {
    return {
      
    }
  },
  methods: {
    check_if_loged() {
      axios.post('LoginLogic/check_login', {
        sid: window.localStorage.getItem('session-id')
      })
      .then(response => {
        if ('user_data' in response.data) {/* no action needed */}
        else {store.commit('SET_USER_LOGEDOUT')}
      })
      .catch(e => {console.log(e)})
    }
  },
  computed: {
    user_status(){
      let user_object = store.state
      return user_object
    }
  },
  mounted() {
    this.check_if_loged()
  }
}
</script>

<style>
  :root {
    --main-bg-color: #23282b;
    --main-font-color: #fff;
    --main-red-color: #ff6e60;
  }
  *{
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  *::selection {background-color: #ccc}
  /* .phone-screen *::selection {background-color: transparent} */
  body {
    font-family: 'Sulphur Point','Avenir', Helvetica, Arial, sans-serif;
    background-color: var(--main-bg-color);
    color: var(--main-font-color);
    background-image: url('./assets/images/app/mobile-background.jpg'); 
    background-attachment: fixed;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    overflow-x: hidden;
  }
  .app {
    min-height: 100vh;
    text-align: center;
  }
  .router-link-exact-active {color: var(--main-red-color)}

  a {
    display: inline-block;
    text-decoration: none;
    font-weight: bold;
    color: var(--main-font-color);
    transition: 250ms ease-in-out;
  }
  label {
    display: block;
    font-weight: 300;
    text-transform: uppercase;
    margin-top: 20px;
    margin-bottom: 10px;
  }
  input, select {
    padding: 10px 15px 5px 15px;
    font-size: 1.4rem;
    font-weight: 300;
    color: #dadada;
    border: none;
    border-bottom: 2px solid #626365;
    background: #23282b9a;
    text-align: center;
    display: block;
    margin: 0 auto 10px auto;
    width: 90%;
  }
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {-webkit-appearance: none}
  input[type=number] {-moz-appearance: textfield}
  input::placeholder { font-family: 'Sulphur Point','Avenir', Helvetica, Arial, sans-serif }
  input:focus,
  select:focus { outline: 1px solid var(--main-red-color) }
  select {text-align-last: center}
  option {background-color: var(--main-bg-color)}

  button {
    border-radius: 300px;
    color: var(--main-red-color);
    background-color: transparent;
    border-color: var(--main-red-color);
    padding: 15px 30px;
    font-size: 15px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: 150ms ease-in-out;
    outline: none;
    margin-top: 25px;
    cursor: pointer;
  }
  button:hover {
    color: var(--main-font-color);
    background-color: var(--main-red-color);
  }
  .icon { color: var(--main-red-color) }
  .home-btn {
    position: absolute;
    bottom: 4.3%;
    left: 50%;
    transform: translateX(-50%);
    font-size: 2.5rem;
    color: #23282b;
    transition: 150ms ease-in;
    cursor: pointer;
  }
  .home-btn:hover, .return-btn:hover {
    color: #32373a;
  }
  .return {
    display: block;
    font-size: 1.3rem;
    color: var(--main-red-color);
    padding: 10px 20px 10px 10px;
    cursor: pointer;
    transition: 150ms ease-in-out;
    margin-top: 15px;
  }
  .return:hover {transform: translateX(-5px)}
  .response {
    min-height: 2rem;
    display: block;
    /* border: 1px dashed white; */
    margin-top: 25px; 
    color: var(--main-red-color);
    font-size: 1.2rem;
    transition: 250ms ease-in-out;
  }
  .title {text-align: center}
  


  /*---------- FOR MOBILE VIEW ------------*/
  
  .desktop-view {
    display: none;
    height: 100vh;
    background-image: url('./assets/images/app/desktop-background.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
  }

  /*-- Right side view --*/
  

  /*-- Left side view --*/
  .phone-wrapper {
    display: inline-block;
    position: relative;
    height: 99vh;
  }
  .phone-case {
    display: inline-block;
    height: 100%;
    position: relative;
  }
  .phone-screen {
    /* border: 1px dashed white; */
    height: 81.3%;
    width: 86%;
    position: absolute;
    top: 8%;
    left: 6.8%;
    background-color: var(--main-bg-color);
    background-image: url('./assets/images/app/mobile-background.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    padding: 5px;
    overflow-y: scroll;
    overflow-x: hidden;
    scrollbar-width: thin;
    scrollbar-color: var(--main-red-color) #111516;
  }
  
  ::-webkit-scrollbar {width: 2px}
  ::-webkit-scrollbar-thumb {background: var(--main-red-color)}
  ::-webkit-scrollbar-track {background-color: #111516}
  ::-webkit-scrollbar-track {background-color: #111516}

  .have-acc {
    color: var(--main-red-color);
    font-weight: 700;
    text-align: right;
    padding: 10px 10px 0 0;
    margin-bottom: 50px;
    display: block;
    text-decoration: none;
    cursor: pointer;
  }
  .have-acc:hover {
    text-decoration: underline;
  }
  .title {
    font-size: 1.3rem;
    text-transform: uppercase;
    text-align: center;
  }
  .hero {
    /* border: 1px dashed white; */
    font-weight: 700;
    margin-top: 20px;
  }
  .hero img {
    width: 85%;
    display: inline-block;
    border-bottom: 2px solid #626365;
  }
  .hero p {
    font-size: 1.2rem;
    margin-top: 25px;
  }
  .hero button {
    margin: 20px 0;
    cursor: pointer;
  }

  
  




  /*---- ON BIGER SCREENS ----*/
  @media screen and (min-width: 430px) {
    .mobile-view { display: none }
    .desktop-view {
      display: flex;
      justify-content: space-around;
    }
  }

  /*---- ON TABLET SCREENS ----*/
  @media screen and (max-width: 950px) {
    .desktop-screen {display: none}
  }
</style>
