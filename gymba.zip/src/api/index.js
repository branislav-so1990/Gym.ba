import instance from './config.js';
export default instance;

// export default {
//   logIn(param) {
//     return instance.post('/login', param)
//   }
// };